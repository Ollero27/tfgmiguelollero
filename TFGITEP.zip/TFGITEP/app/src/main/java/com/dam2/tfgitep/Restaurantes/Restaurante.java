/*
package com.dam2.tfgitep.Restaurantes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.dam2.tfgitep.DBHelper;
import com.dam2.tfgitep.Hoteles.Hotel;
import com.dam2.tfgitep.R;

import java.util.ArrayList;

public class Restaurante extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String> nombre, ubicacion, pais, map;
    DBHelper DB;
    DBHelper.MyAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurante);
        DB = new DBHelper(this);

        Button buttonmap = findViewById(R.id.linkmap);

        nombre = new ArrayList<>();
        ubicacion = new ArrayList<>();
        pais = new ArrayList<>();
        map = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerview);
        adapter = new DBHelper.MyAdapter(this,nombre, ubicacion, pais);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displaydata();

    }

    private void displaydata() {
        String paisdato = getIntent().getStringExtra("datopais");

        Cursor cursor = DB.getdataHoteles(paisdato);
        if(cursor.getCount()==0){
            Toast.makeText(Restaurante.this, " No hay entradas", Toast.LENGTH_SHORT).show();
            return;
        }else{
            while(cursor.moveToNext()){
                nombre.add(cursor.getString(1));
                ubicacion.add(cursor.getString(2));
                pais.add(cursor.getString(3));
            }
        }
    }

}
*/
