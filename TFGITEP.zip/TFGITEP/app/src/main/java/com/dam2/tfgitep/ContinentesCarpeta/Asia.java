package com.dam2.tfgitep.ContinentesCarpeta;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.dam2.tfgitep.LoginActivity;
import com.dam2.tfgitep.Paises.China;
import com.dam2.tfgitep.Paises.India;
import com.dam2.tfgitep.Paises.Japon;
import com.dam2.tfgitep.R;

public class Asia extends AppCompatActivity {

    Button ChinaBtn;
    Button JaponBtn;
    Button IndiaBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asia);

        // calling the action bar
        ActionBar actionBar = getSupportActionBar();

        // showing the back button in action bar
        actionBar.setDisplayHomeAsUpEnabled(true);

        ChinaBtn=(Button)findViewById(R.id.buttonChina);
        JaponBtn=(Button)findViewById(R.id.buttonJapon);
        IndiaBtn=(Button)findViewById(R.id.buttonIndia);

        ChinaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentChina=new Intent(Asia.this, China.class);
                startActivity(intentChina);
            }
        });

        JaponBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentJapon=new Intent(Asia.this, Japon.class);
                startActivity(intentJapon);
            }
        });

        IndiaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentIndia=new Intent(Asia.this, India.class);
                startActivity(intentIndia);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_logout:
                logOut();
                return true;
            case android.R.id.home:
                this.finish();
                return true;
            default :
                return super.onOptionsItemSelected(item);
        }
    }

    private void logOut (){
        Intent intent = new Intent (this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
