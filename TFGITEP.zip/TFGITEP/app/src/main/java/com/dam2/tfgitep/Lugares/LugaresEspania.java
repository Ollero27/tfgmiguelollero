package com.dam2.tfgitep.Lugares;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dam2.tfgitep.DBHelper;
import com.dam2.tfgitep.LoginActivity;
import com.dam2.tfgitep.R;



public class LugaresEspania extends AppCompatActivity {

    private LinearLayout blink1, blink2, blink3;


    String url1 = "https://goo.gl/maps/NCh51RCNqykKLgfF8";
    String url2 = "https://goo.gl/maps/mnPKMXJ2eVwcZt7L6";
    String url3 = "https://goo.gl/maps/QaEPNDpYa2FPEzsYA";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lugares_espania);

        blink1 = findViewById(R.id.btnlink1);
        blink2 = findViewById(R.id.btnlink2);
        blink3 = findViewById(R.id.btnlink3);




        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

        blink1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
         Uri _link = Uri.parse(url1);
         Intent maps = new Intent(Intent.ACTION_VIEW,_link);
         startActivity(maps);
         }
        });

        blink2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri _link = Uri.parse(url2);
                Intent maps = new Intent(Intent.ACTION_VIEW,_link);
                startActivity(maps);
            }
        });

        blink3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri _link = Uri.parse(url3);
                Intent maps = new Intent(Intent.ACTION_VIEW,_link);
                startActivity(maps);
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_logout:
                logOut();
                return true;
            case android.R.id.home:
                this.finish();
                return true;
            default :
                return super.onOptionsItemSelected(item);
        }
    }


    private void logOut (){
        Intent intent = new Intent (this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}