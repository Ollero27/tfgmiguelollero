package com.dam2.tfgitep;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "Login.db";

    public DBHelper(Context context) {
        super(context, "Login.db", null, 7);
    }




    @Override
    public void onCreate(SQLiteDatabase MyDB) {

        MyDB.execSQL("create Table users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, address TEXT)");
        MyDB.execSQL("INSERT INTO users VALUES(null,'admin','admin','admin');");
        MyDB.execSQL("INSERT INTO users VALUES(null,'a','a','a');");
        MyDB.execSQL("create Table lugares (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, location TEXT, country TEXT)");
        MyDB.execSQL("INSERT INTO lugares VALUES(null,'plaza españa','https://goo.gl/maps/NCh51RCNqykKLgfF8', 'españa');");
        MyDB.execSQL("INSERT INTO lugares VALUES(null,'teide','https://goo.gl/maps/QaEPNDpYa2FPEzsYA', 'españa');");
        MyDB.execSQL("INSERT INTO lugares VALUES(null,'sagrada familia','https://goo.gl/maps/mnPKMXJ2eVwcZt7L6', 'españa');");
        MyDB.execSQL("INSERT INTO lugares VALUES(null,'torre eiffel','https://goo.gl/maps/mnPKMXJ2eVwcZt7L6', 'francia');");

        /*MyDB.execSQL("create Table hoteles(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, location TEXT, country TEXT)");
        MyDB.execSQL("INSERT INTO hoteles VALUES(null,'hotel1','https://goo.gl/maps/NCh51RCNqykKLgfF8', 'españa');");
        MyDB.execSQL("INSERT INTO hoteles VALUES(null,'hotel2','https://goo.gl/maps/QaEPNDpYa2FPEzsYA', 'españa');");
        MyDB.execSQL("INSERT INTO hoteles VALUES(null,'hotel3','https://goo.gl/maps/mnPKMXJ2eVwcZt7L6', 'españa');");
        MyDB.execSQL("INSERT INTO hoteles VALUES(null,'hotel4','https://goo.gl/maps/mnPKMXJ2eVwcZt7L6', 'francia');");

        MyDB.execSQL("create Table restaurantes(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, location TEXT, country TEXT)");
        MyDB.execSQL("INSERT INTO restaurantes VALUES(null,'hotel1','https://goo.gl/maps/NCh51RCNqykKLgfF8', 'españa');");
        MyDB.execSQL("INSERT INTO restaurantes VALUES(null,'hotel2','https://goo.gl/maps/QaEPNDpYa2FPEzsYA', 'españa');");
        MyDB.execSQL("INSERT INTO restaurantes VALUES(null,'hotel3','https://goo.gl/maps/mnPKMXJ2eVwcZt7L6', 'españa');");
        MyDB.execSQL("INSERT INTO restaurantes VALUES(null,'hotel4','https://goo.gl/maps/mnPKMXJ2eVwcZt7L6', 'francia');");*/
    }


    public Cursor getdataLugares(String country){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from lugares where country = ?", new String[]{country});
        return cursor;
    }

    public Cursor getdataHoteles(String country){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from hoteles where country = ?", new String[]{country});
        return cursor;
    }

    public Cursor getdataRestaurantes(String country){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from restaurantes where country = ?", new String[]{country});
        return cursor;
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {

        MyDB.execSQL("drop Table users");
        MyDB.execSQL("drop Table lugares");
        onCreate(MyDB);
    }




    public Boolean insertData(String username, String password, String address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("address", address);

        long result = MyDB.insert("users", null, contentValues);
        if(result==-1) return false;
        else
            return true;
    }


    public Boolean checkuseraddress(String address) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where address = ?", new String[]{address});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkusernamepassword(String address, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where address = ? and password = ?", new String[] {address,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }


    public Boolean updateuserdata(String username, String password, String address)
    {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        Cursor cursor = MyDB.rawQuery("Select * from users where address = ?", new String[]{address});
        if (cursor.getCount() > 0) {
            long result = MyDB.update("users", contentValues, "address=?", new String[]{address});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Boolean deletedata (String address)
    {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where address = ?", new String[]{address});
        if (cursor.getCount() > 0) {
            long result = MyDB.delete("users", "address=?", new String[]{address});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdata ()
    {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users", null);
        return cursor;
    }


    public static class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

        private Context context;
        private ArrayList nombre_id, ubicacion_id, pais_id, map_id;


        public MyAdapter(Context context, ArrayList nombre_id, ArrayList ubicacion_id, ArrayList pais_id, ArrayList map_id) {
            this.context = context;
            this.nombre_id = nombre_id;
            this.ubicacion_id = ubicacion_id;
            this.pais_id = pais_id;
            this.map_id = map_id;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.userentry,parent,false);
            return new MyViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.nombre_id.setText(String.valueOf(nombre_id.get(position)));
            holder.ubicacion_id.setText(String.valueOf(ubicacion_id.get(position)));
            holder.pais_id.setText(String.valueOf(pais_id.get(position)));
        }

        @Override
        public int getItemCount() {
            return nombre_id.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {


            TextView nombre_id, ubicacion_id, pais_id;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);

                nombre_id = itemView.findViewById(R.id.textnombre);
                ubicacion_id = itemView.findViewById(R.id.textubicacion);
                pais_id = itemView.findViewById(R.id.textpais);
                itemView.findViewById(R.id.linkmap).setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        Log.i("info", "boton");
                        Intent linksmaps = new Intent(Intent.ACTION_VIEW,Uri.parse("https://goo.gl/maps/NCh51RCNqykKLgfF8"));
                        context.startActivity(linksmaps);
                    }
                });
            }
        }
    }
}
